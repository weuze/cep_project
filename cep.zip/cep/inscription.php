<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cep_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
  echo "Impossible de se connecter";
}

// get the service
$sql_request_service = "SELECT * FROM `service`";
$service = $conn->query($sql_request_service); 

var_dump($_POST);
if (
  isset($_POST['pseudo']) && isset($_POST['password']) &&
  isset($_POST['nom']) && isset($_POST['prenom']) &&
  isset($_POST['email']) && isset($_POST['service']) &&
  isset($_POST['fonction']) && isset($_POST['confirm_password'])
  ) { 
    $sql_request = "INSERT INTO user(nom,prenom,email,pseudo,mdp,adress,service_code_service) 
  VALUES('".$_POST['nom']."','".$_POST['prenom']."','".$_POST['email']."','".$_POST['pseudo']."','".
        $_POST['password']."','".$_POST['adress']."',".$_POST['service'].")"; 
        echo $sql_request;
        if ($conn->query($sql_request)==TRUE) {
          echo "<script>location.href='login.php';</script>";
        } else {
          echo "Impossible dinserer";
        }
      }
      else {
        echo "<p>Veuillez saisir tout les informations</p>";
      }

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>CEP</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="css/main.css">

</head>

<body>

  <div class="wrap">
    <div class="login_form_container">
      <img src="assets/images/guide-formation-it-2-7.jpg" alt="">

      <h3>Inscriver-Vous</h3><br>
      <form method="POST" action="inscription.php">
            <div class="form-group">
              <label for="logininput">Pseudo</label>
              <input type="text" class="form-control" name="pseudo" id="pseudoinput" placeholder="Entrer pseudo">
            </div>
            <div class="form-group">
              <label for="logininput">Nom</label>
              <input type="text" class="form-control" name="nom" id="nominput" placeholder="Entrer nom">
            </div>
            <div class="form-group">
              <label for="logininput">prenom</label>
              <input type="text" class="form-control" name="prenom" id="prenominput" placeholder="Entrer prenom">
            </div>
            <div class="form-group">
              <label for="logininput">Email</label>
              <input type="email" class="form-control" name="email" id="emailinput" placeholder="exemple@live.com">
            </div>
            <div class="form-group">
              <label for="logininput">Fonction</label>
              <input type="text" class="form-control" name="fonction" id="fonctioninput" placeholder="Entrer fonction">
            </div>

            <div class="form-group">
                <label for="service">Service</label>
                <select class="form-control" id="service" name="service">
                <?php  while($row = $service->fetch_assoc()) { 
                  echo "<option value='".$row['code_service']."'>".$row['libelle']."</option>";
              }?>
              </select>
            </div>

            <div class="form-group">
              <label for="passwordinput">Mot de Passe</label>
              <input type="password" name="password" class="form-control" id="passwordinput" placeholder=" Entrer mot de passe">
            </div>
            <div class="form-group">
              <label for="passwordinput">Confirmer Votre Mot de Passe</label>
              <input type="password" name="confirm_password" class="form-control" id="passwordinput" placeholder=" confirmer votre mot de passe mot de passe">
            </div>
            <button type="submit" class="btn btn-block btn-danger">Valider</button>


          </form>
        </div>

    </div>
</body>

</html>